<?php
include "config/db.php";
if(isset($_POST['register'])){
 $name=$_POST['name']; $email=$_POST['email'];
 $pass=password_hash($_POST['password'], PASSWORD_DEFAULT);
 $role=$_POST['role']; $area=$_POST['area'];
 $q=mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");
 if(mysqli_num_rows($q)>0){ echo "Email exists"; exit; }
 mysqli_query($conn,"INSERT INTO users(name,email,password,role,area)
 VALUES('$name','$email','$pass','$role','$area')");
 echo "Registered";
}
?>
<form method="post">
<input name="name" placeholder="Name" required>
<input name="email" type="email" placeholder="Email" required>
<input name="password" type="password" placeholder="Password" required>
<select name="role"><option value="user">User</option><option value="provider">Provider</option></select>
<input name="area" placeholder="Area" required>
<button name="register">Register</button>
</form>