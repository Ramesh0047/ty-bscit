<?php
session_start(); include "config/db.php";
if(isset($_POST['login'])){
 $email=$_POST['email']; $pass=$_POST['password'];
 $q=mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");
 $u=mysqli_fetch_assoc($q);
 if($u && password_verify($pass,$u['password'])){
  $_SESSION['user_id']=$u['user_id'];
  $_SESSION['role']=$u['role'];
  if($u['role']=='admin') header("Location: admin/dashboard.php");
  elseif($u['role']=='provider') header("Location: provider/dashboard.php");
  else header("Location: user/dashboard.php");
 } else echo "Invalid login";
}
?>
<form method="post">
<input name="email" type="email" placeholder="Email">
<input name="password" type="password" placeholder="Password">
<button name="login">Login</button>
</form>