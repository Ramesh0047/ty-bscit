<?php
session_start();
if($_SESSION['role']!='user') header("Location: ../login.php");
?>
<h2>User Dashboard</h2>
<a href="../logout.php">Logout</a>