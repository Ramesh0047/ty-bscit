<?php
session_start();
if($_SESSION['role']!='provider') header("Location: ../login.php");
?>
<h2>Provider Dashboard</h2>
<a href="../logout.php">Logout</a>